import User from "../models/user.js";
import chat from "../models/chat.js";

export const addfriend =async (req, res) => {
console.log(req.body);

     let user=await User.findOne({clerkId:req.body.userId});
 

const alreadyFriend = user.friends.some(
  (f) => f.user.toString() === req.body.friendId
);

if (alreadyFriend) {
  return res.json({ message: "Friend already exists" });
}
let checkchat=await chat.findOne({members:{$all:[user._id,req.body.friendId]}});

if(checkchat){
   if(user){
    user.friends.push({user:req.body.friendId,chatId:checkchat._id});
    await user.save();
   return res.json({ message:"friend added"});
    }

}
let createchat=await chat.create({type:"private",members:[user._id,req.body.friendId]});
    if(user){
    user.friends.push({user:req.body.friendId,chatId:createchat._id});
    await user.save();
    res.json({ message:"friend added"});
    }
};