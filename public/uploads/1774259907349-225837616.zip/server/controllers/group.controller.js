import groups from "../models/groups.js";
import User from "../models/user.js";
import chat from "../models/chat.js";
export const addgroup=async(req,res)=>{
    const { name,members,adminId}=req.body
 const allMembers = [...new Set([...members, adminId])];
 let chatid=await chat.create({type:"group",members:allMembers});
 
    let group=await groups.create({name:name,members:[...members,adminId],admin:adminId,chatid:chatid._id});
   
    await User.updateMany(
      { _id: { $in: allMembers } },
      { $addToSet: { groups: group._id } } 
    );
   

res.json({message:"group added"});

}