let io;
import { Server } from "socket.io";

export const initSocket = (server) => {
  io = new Server(server, {
    cors: {
      origin: "*",
    },
  });

  io.on("connection", (socket) => {
    console.log("User connected:", socket.id);

    // USER JOIN WITH MONGO USER ID
    socket.on("user", ({ mongouid }) => {
       socket.userId = mongouid;  
      socket.join(mongouid);
      console.log("User joined personal room:", mongouid);
    });

    // JOIN PRIVATE CHAT
    socket.on("join-chat", ({ chatId }) => {
      socket.join(chatId);
      console.log("User joined chat:", chatId);
    });

    // JOIN GROUP CHAT
    socket.on("join-groupchat", ({ chatId }) => {
      socket.join(chatId);
      console.log("User joined group chat:", chatId);
    });

    // SEND MESSAGE
    socket.on("send-message", (data) => {
      const { receiverId, groupId } = data;

      if (receiverId) {
        io.to(receiverId).emit("receive-message", data);
      }

      if (groupId) {
        io.to(groupId).emit("receive-message", data);
      }
    });

    // LEAVE CHAT
    socket.on("leave-chat", (data) => {
      if (!data) return;

      const { chatId} = data;

      socket.leave(chatId);
      

      console.log("User left:", chatId);
    });

    // CALL USER
    socket.on("call-user", ({ toUserId, fromUserId, callType, name, url, users }) => {

      if (Array.isArray(toUserId)) {

        const targets = toUserId.filter(id => id !== fromUserId);

        console.log("Calling users:", targets);

        targets.forEach(id => {

          io.to(id).emit("incoming-call", {
            fromUserId,
            callType,
            name,
            url,
            users
          });

        });

      } else {

        io.to(toUserId).emit("incoming-call", {
          fromUserId,
          callType,
          name,
          url,
          users
        });

      }

    });


    
    socket.on("accept-call", ({ toUserId }) => {

      console.log("Call accepted by:", socket.userId);

      io.to(toUserId).emit("call-accepted", socket.userId);

    });


    // =========================
    // REJECT CALL
    // =========================
    socket.on("reject-call", ({ toUserId }) => {

      io.to(toUserId).emit("call-rejected", socket.userId);

    });


    // =========================
    // WEBRTC SIGNALING
    // =========================

    // OFFER
    socket.on("offer", ({ toUserId, offer }) => {

      console.log("Offer from", socket.userId, "to", toUserId);

      io.to(toUserId).emit("offer", {
        offer,
        fromUserId: socket.userId
      });

    });


    // ANSWER
    socket.on("answer", ({ toUserId, answer }) => {

      console.log("Answer from", socket.userId, "to", toUserId);

      io.to(toUserId).emit("answer", {
        answer,
        fromUserId: socket.userId
      });

    });


    // ICE CANDIDATE
    socket.on("ice-candidate", ({ toUserId, candidate }) => {

      io.to(toUserId).emit("ice-candidate", {
        candidate,
        fromUserId: socket.userId
      });

    });


    // =========================
    // END CALL
    // =========================
    socket.on("end-call", ({ users }) => {

      if (!users) return;

      users.forEach((id) => {

        if (id !== socket.userId) {

          io.to(id).emit("call-ended", {
            fromUserId: socket.userId
          });

        }

      });

      console.log("Call ended by:", socket.userId);

    });


    

    socket.on("disconnect", () => {
      console.log("User disconnected:", socket.id);
    });

  });

  return io;
};

export const getIO = () => io;